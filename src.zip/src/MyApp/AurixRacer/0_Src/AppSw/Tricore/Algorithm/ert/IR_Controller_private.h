/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: IR_Controller_private.h
 *
 * Code generated for Simulink model 'IR_Controller'.
 *
 * Model version                  : 1.135
 * Simulink Coder version         : 8.13 (R2017b) 24-Jul-2017
 * C/C++ source code generated on : Fri May  4 09:46:39 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Infineon->TriCore
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_IR_Controller_private_h_
#define RTW_HEADER_IR_Controller_private_h_
#include "rtwtypes.h"

/* Includes for objects with custom storage classes. */
#include "Basic.h"
#include "InfineonRacer.h"
#endif                                 /* RTW_HEADER_IR_Controller_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
