#ifndef BASIC_H_
#define BASIC_H_

#include "BasicLineScan.h"
#include "BasicPort.h"
#include "BasicGtmTom.h"
#include "BasicVadcBgScan.h"
#include "BasicGpt12Enc.h"

#endif /* APPTASKFU_H_ */
