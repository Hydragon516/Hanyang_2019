#ifndef DISPLAYIO_H_
#define DISPLAYIO_H_

#include <Ifx_Types.h>

void display_io_init(void);
void display_io_run(void);

#endif /* DISPLAYIO_H_ */
